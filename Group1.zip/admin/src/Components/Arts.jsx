import React from 'react'
import Navbar from '../Parts/Navbar'

function Arts() {
  return (
    <div>
      <Navbar />
      <h1>Arts</h1>
    </div>
  )
}

export default Arts