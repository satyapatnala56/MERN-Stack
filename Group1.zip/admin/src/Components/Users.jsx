import React from 'react'
import Navbar from '../Parts/Navbar'
import Table from './Table'

function Users() {
  return (
    <div>
    <Navbar />
        Users
        <Table />
        </div>
  )
}

export default Users