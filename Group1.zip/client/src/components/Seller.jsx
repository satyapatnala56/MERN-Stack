import React from 'react'
import { DarkP, StyledP } from '../stlying/styles'

function Seller() {
  return (
    <div>
        <DarkP>HfJEXElijLIjfeL</DarkP>
    </div>
  )
}

export default Seller