const dark = '#000';
const white = '#fff';
const lightwhite = 'aliceblue';
const lightdark = 'grey'

// const backimg = 'https://content3.jdmagicbox.com/comp/midnapore/d2/9999p3222.3222.190503100000.v8d2/catalogue/art-craft-drawing-classes-midnapore-glass-painting-classes-1gqooafrsr.jpg?clr=442d22'
const backimg = 'https://wallup.net/wp-content/uploads/2018/09/30/55965-women-abstract-surreal-fantasy-art.jpg'
// const backimg = 'https://www.mapsofindia.com/ci-moi-images/my-india/2014/11/art.jpg'

export  {
dark,white,lightwhite,
lightdark,backimg
};