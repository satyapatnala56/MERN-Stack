After unzipping please follow the following steps
For running Client
-- cd client
-- npm install
-- npm start

For running server

-- cd server
-- npm install
-- npm start

For running admin
-- cd admin
-- npm install
-- npm start
